<?php
error_reporting(E_ALL);
ini_set('display_errors', 'on');
session_start();
if(isset($_REQUEST['submit'])){
    $_SESSION['Name']=$_REQUEST['Name'];
    $_SESSION['Surname']=$_REQUEST['Surname'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style_4.css">
    <link rel="shortcut icon" href="img/logo.jpg" type="image/jpg">
    <title>Авторизация</title>
</head>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
    <p>
		<input  type="text" name="Name" placeholder="Ваше имя">
    <p>
		<input  type="text" name="Surname" placeholder="Ваша фамилия">
    <p>
		<input type="email" name="Email" placeholder="Ваш Email">
    <p>
        <input class="button" type="submit" name="submit" placeholder="Авторизироваться">
</form>
</body>
</html>


