<div class = footer_1>
        <div id = footer_1_l>
        <div class = icon><a href ="#"><img src="img/4.7.png" alt=""></a></div>
        <div class = icon><a href ="#"><img src="img/4.8.jpg" alt=""></a></div>
        <div class = icon><a href ="#"><img src="img/4.9.jpg" alt=""></a></div>
        <div class = icon><a href ="#"><img src="img/4-10.jpg" alt=""></a></div>    
        <a class = text_1 href ="#">(096) 705-92-92</a>
        </div>
        <div id = footer_1_r>
            <div class = text_1>г. Днепр ул. В. Великого 67 дом 7а</div>
            <div class = icon><a href ="#"><img src="img/4.11.png"></a></div>
        </div>
        
    </div>
    <div class = footer_2>Copyright © 2020 Верность - Днепропетровское общество защиты животных - благотворительная общественная организация.
</div>