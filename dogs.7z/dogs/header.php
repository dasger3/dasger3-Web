<style>
   .avtor { 
		font-size:25px;
		text-decoration:none;
		color:black;
		margin-right:8px;
		margin-top:8px;
   }
 </style>
<div class=header>
    <div class = header_l>
        <div class = lapka></div>
        <div class = lapka></div>
        <div class = lapka></div>
        <div class = lapka></div>
        <div class = lapka></div>
    </div>
    <div class = header_r>
        <a class ="avtor" href="post.php">
			<?php
				session_start();
				if(empty($_SESSION['Name'])or empty($_SESSION['Surname'])){
					echo "Авторизироваться";
				}
				else {
					echo $_SESSION['Name'], " ";
					echo $_SESSION['Surname'];
				}
			?>
		</a>
    </div>
 </div>
 