<?php
require "header.php";
$page = $_GET['page'];
$page=stripslashes($page); 
$page=htmlentities($page);
$page=addslashes($page); 
require "$page";
require "footer.php";
?>